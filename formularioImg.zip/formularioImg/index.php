<?php
// Comprobamos si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Recogemos los datos del formulario directamente sin limpiar entradas
    $nombre = $_POST['nombre'];
    $alias = $_POST['alias'];
    $edad = intval($_POST['edad']);
    $armas = isset($_POST['armas']) ? implode(', ', $_POST['armas']) : 'Ninguna';
    $magia = $_POST['magia'];

    // Manejo de la subida de imagen
    $imagenSubida = false;
    $mensajeError = '';

    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] == 0) {
        $imagen = $_FILES['imagen'];
        
        // Verificamos el tipo de archivo y su tamaño
        $tipoArchivo = mime_content_type($imagen['tmp_name']);
        if ($tipoArchivo === 'image/png' && $imagen['size'] <= 10240) {
            $rutaDestino = 'uploads/' . basename($imagen['name']);
            if (move_uploaded_file($imagen['tmp_name'], $rutaDestino)) {
                $imagenSubida = true;
            } else {
                $mensajeError = "Error al subir la imagen.";
            }
        } else {
            $mensajeError = "Solo se permiten archivos PNG de máximo 10KB.";
        }
    }

    // Mostramos los datos del jugador
    echo "<div style='background-color: rgba(135 131 148 / 0.71); padding: 20px; margin: 20px auto; width: 500px; heigth: 600px text-align: center; border-radius: 10px;'>";
    echo "<h2>Datos del Jugador</h2>";
    echo "<p><strong>Nombre:</strong> $nombre</p>";
    echo "<p><strong>Alias:</strong> $alias</p>";
    echo "<p><strong>Edad:</strong> $edad</p>";
    echo "<p><strong>Armas seleccionadas:</strong> $armas</p>";
    echo "<p><strong>¿Practica artes mágicas?:</strong> $magia</p>";
        
    if ($imagenSubida) {
        echo "<p><strong>Imagen subida:</strong></p>";
        echo "<img src='$rutaDestino' alt='Imagen del jugador' style='max-width: 100px;'>";
    } else {
        echo "<p><strong>No se subió ninguna imagen.</strong></p>";
        echo "<img src='uploads/calavera.png' alt='Error' style='max-width: 100px;'>";
        if ($mensajeError) {
            echo "<p style='color: red;'>$mensajeError</p>";
        }
    }
    echo "</div>";
} else {
    // Si la solicitud es GET, redirigimos al formulario
    header('Location: captura.html');
}
?>
